package com.helloretail.interviewtask.repository;

import com.helloretail.interviewtask.domain.Product;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * A mock representation of Products JPA repository. It uses static list of Products loaded from
 * json files. This Class can be deleted once datasource configuration is added
 */
@Repository
public class ProductRepositoryImpl implements ProductRepository<Product, BigInteger> {

  private static final Logger LOGGER = LoggerFactory.getLogger(ProductRepositoryImpl.class);

  @Autowired
  @Qualifier("productList")
  private List<Product> productList;

  @Override
  public List<Product> findAll() {
    LOGGER.info("Fetching all products");
    return new ArrayList<Product>(productList);
  }

  @Override
  public Page<Product> findAll(Pageable pageable) {
    List<Product> products = new ArrayList<>(productList);
    LOGGER.info(
        "Sorting products based field selected in Ascending order first::{}", pageable.getSort());
    products.sort(
        (o1, o2) ->
            pageable.getSort().stream()
                .map(
                    order -> {
                      if (order.getProperty().equalsIgnoreCase("price")) {
                        return o1.getPrice().compareTo(o2.getPrice());
                      } else if (order.getProperty().equalsIgnoreCase("title")) {
                        return o1.getTitle().compareTo(o2.getTitle());
                      } else return o1.getId().compareTo(o2.getId());
                    })
                .findFirst()
                .get());
    if (pageable.getSort().get().findFirst().get().isDescending()) {
      LOGGER.info("Reversing the list since sort direction is descending::{}", pageable.getSort());
      Collections.reverse(products);
    }
    int totalCount = productList.size();
    int start = (pageable.getPageNumber() - 1) * pageable.getPageSize();
    int end =
        pageable.getOffset() > totalCount
            ? totalCount
            : Long.valueOf(pageable.getOffset()).intValue();
    LOGGER.info("Slicing sorted list based on paging criteria ::start={}, end={}", start, end);
    List<Product> subListProducts = products.subList(start, end);
    return new PageImpl<Product>(subListProducts, pageable, totalCount);
  }

    @Override
    public Optional<Product> findById(BigInteger id) {
        return productList.stream().filter(product -> product.getId().equals(id)).findFirst();
    }
}
