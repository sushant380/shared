package com.helloretail.interviewtask.dto;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.math.BigInteger;

/** Data transfer object for {@link com.helloretail.interviewtask.domain.Product} Entity */
@Builder
@Getter
public class ProductDto {
  private BigInteger id;
  private String title;
  private BigDecimal price;
  private String image;
}
