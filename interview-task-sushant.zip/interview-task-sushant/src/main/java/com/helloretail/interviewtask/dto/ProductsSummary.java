package com.helloretail.interviewtask.dto;

import lombok.Builder;
import lombok.Getter;
import org.springframework.hateoas.RepresentationModel;

import java.util.List;

/**
 * Data transfer object for {@link com.helloretail.interviewtask.domain.Product} Entity and links to
 * next and previous pages. This class is extended to {@link RepresentationModel} to have hateoas
 * links
 */
@Builder
@Getter
public class ProductsSummary extends RepresentationModel<ProductsSummary> {
  private List<ProductDto> products;
  private Long total;
}
