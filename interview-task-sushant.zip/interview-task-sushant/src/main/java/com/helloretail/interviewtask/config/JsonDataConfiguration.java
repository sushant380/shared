package com.helloretail.interviewtask.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.helloretail.interviewtask.domain.Product;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.stream.Collectors;

/** Configuration to read json files from resources folder to serve as data source for repository */
@Configuration
public class JsonDataConfiguration {

  @Bean
  @Qualifier("productList")
  public List<Product> jsonData() throws IOException {
    ObjectMapper mapper = new ObjectMapper();
    return Files.list(ResourceUtils.getFile("classpath:static/feed").toPath())
        .map(
            file -> {
              JsonNode data = null;
              try {
                data = mapper.readTree(file.toFile()).get("products");
              } catch (IOException e) {
                e.printStackTrace();
              }
              return mapper.convertValue(data, new TypeReference<List<Product>>() {});
            })
        .flatMap(list -> list.stream())
        .collect(Collectors.toList());
  }
}
