package com.helloretail.interviewtask.service;

import com.helloretail.interviewtask.domain.Product;
import com.helloretail.interviewtask.dto.ProductDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/** Mapper class to transfer {@link Product} entity data to {@link ProductDto} */
@Service
public class ProductMapper {
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductMapper.class);

  /**
   * Map {@link Product} data to {@link ProductDto} data transfer object.
   * @param product Product entity
   * @return product DTO
   */
  ProductDto toDto(Product product) {
    return ProductDto.builder()
        .id(product.getId())
        .price(product.getPrice())
        .title(product.getTitle())
        .image(product.getImage())
        .build();
  }

  /**
   * Map list of {@link Product} to list of {@link ProductDto}.
   * @param list product entities
   * @return list of product dtos.
   */
  List<ProductDto> toList(List<Product> list) {
    LOGGER.info("Mapping list of products to list of dtos:: total::{}", list.size());
    return list.stream().map(this::toDto).collect(Collectors.toList());
  }
}
