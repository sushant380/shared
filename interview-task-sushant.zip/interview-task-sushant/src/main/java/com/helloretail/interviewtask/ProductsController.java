package com.helloretail.interviewtask;

import com.helloretail.interviewtask.dto.ProductDto;
import com.helloretail.interviewtask.dto.ProductsSummary;
import com.helloretail.interviewtask.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Min;
import java.math.BigInteger;

@RestController
@RequestMapping("/products")
@Validated
@Tag(name = "Products", description = "API for products")
public class ProductsController {

  @Autowired private ProductService productService;

  @Operation(
      summary = "Get list of all products",
      description = "List of products with pagination. It can also be sorted by fields in product")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Products are fetched based on query",
            content = {
              @Content(
                  mediaType = "application/json",
                  schema = @Schema(implementation = ProductsSummary.class))
            })
      })
  @GetMapping
  public ResponseEntity<ProductsSummary> get(
      @Parameter(description = "Natural indexing of page starts from 1", example = "1")
          @RequestParam(value = "page", required = false, defaultValue = "1")
          @Min(value = 1)
          int page,
      @Parameter(description = "Max number of products per request", example = "10")
          @RequestParam(value = "limit", required = false, defaultValue = "10")
          @Min(value = 1)
          int limit,
      @Parameter(description = "Sort by field", example = "price")
          @RequestParam(value = "sortBy", required = false, defaultValue = "id")
          String sortBy,
      @Parameter(description = "Sort order(ascending or descending)", example = "ASC")
          @RequestParam(value = "order", required = false, defaultValue = "ASC")
          Sort.Direction directon) {
    return new ResponseEntity<>(
        productService.getProducts(page, limit, sortBy, directon), HttpStatus.OK);
  }

    @Operation(
            summary = "Get list of all products",
            description = "List of products with pagination. It can also be sorted by fields in product")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Products are fetched based on query",
                            content = {
                                    @Content(
                                            mediaType = "application/json",
                                            schema = @Schema(implementation = ProductsSummary.class))
                            })
            })
    @GetMapping("/{id}")
    public ResponseEntity<ProductDto> getById(
            @Parameter(description = "Product id", example = "1")
            @PathVariable(value = "id")
                    BigInteger id) {
        return new ResponseEntity<>(
                productService.getProductById(id), HttpStatus.OK);
    }
}
