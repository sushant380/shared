package com.helloretail.interviewtask.service;

import com.helloretail.interviewtask.ProductsController;
import com.helloretail.interviewtask.domain.Product;
import com.helloretail.interviewtask.dto.ProductDto;
import com.helloretail.interviewtask.dto.ProductsSummary;
import com.helloretail.interviewtask.exception.ProductNotFoundException;
import com.helloretail.interviewtask.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.Optional;

/**
 * Product service class to connect with Product repository and mapping them to product dto. It also
 * add links for pagination.
 */
@Service
public class ProductService {

  private static final Logger LOGGER = LoggerFactory.getLogger(ProductService.class);

  @Autowired private ProductRepository productRepository;

  @Autowired private ProductMapper productMapper;

  public ProductsSummary getProducts(
      int page, int limit, String sortField, Sort.Direction direction) {
    LOGGER.info("Get products from repository");
    Page<Product> products =
        productRepository.findAll(
            PageRequest.of(
                page, limit, Sort.by(Sort.Direction.valueOf(direction.name()), sortField)));
    LOGGER.info("Get product summary for {} products", products.getSize());
    ProductsSummary summary =
        ProductsSummary.builder()
            .products(productMapper.toList(products.toList()))
            .total(products.getTotalElements())
            .build();
    getLinks(summary, products);
    return summary;
  }

  public ProductDto getProductById(BigInteger id){
     Optional<Product>productOptional= productRepository.findById(id);
     return productOptional.map(productMapper::toDto).orElseThrow(() -> new ProductNotFoundException("Product with id="+id+" not found"));
  }

  private void getLinks(ProductsSummary productSummary, Page<Product> page) {
    LOGGER.info("Adding pagination links to summary");
    if (page.hasNext()) {
      LOGGER.info("Next page number would be {}", page.getPageable().next().getPageNumber());
      productSummary.add(
          WebMvcLinkBuilder.linkTo(
                  WebMvcLinkBuilder.methodOn(ProductsController.class)
                      .get(
                          page.getPageable().next().getPageNumber(),
                          page.getPageable().next().getPageSize(),
                          page.getSort().get().findFirst().get().getProperty(),
                          page.getSort().get().findFirst().get().getDirection()))
              .withRel("next"));
    } else {
      LOGGER.warn(
          "No next page available. We might have reached to the end of list {}",
          page.getPageable());
    }
    if (page.hasPrevious()) {
      LOGGER.info(
          "Previous page number would be {}", page.getPageable().previousOrFirst().getPageNumber());
      productSummary.add(
          WebMvcLinkBuilder.linkTo(
                  WebMvcLinkBuilder.methodOn(ProductsController.class)
                      .get(
                          page.getPageable().previousOrFirst().getPageNumber(),
                          page.getPageable().previousOrFirst().getPageSize(),
                          page.getSort().get().findFirst().get().getProperty(),
                          page.getSort().get().findFirst().get().getDirection()))
              .withRel("previous"));
    } else {
      LOGGER.warn(
          "No previous page available. We might have reached to the start of list {}",
          page.getPageable());
    }
  }
}
