package com.helloretail.interviewtask.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * Data repository for Product entity. This interface can be extended with {@link
 * org.springframework.data.jpa.repository.JpaRepository} to have jpa capabilities. {@link Product}
 * should have @Entity and @Id tags to have jpa behaviour.
 *
 * @param <Product>
 * @param <BigInteger>
 */
public interface ProductRepository<Product, BigInteger> {
  /**
   * Find all products in repository
   * @return List of {@link Product}
   */
  List<Product> findAll();

  /**
   * Find all products based on Paging criteria
   * @param pageable pageable criteria
   * @return Page of products
   */
  Page<Product> findAll(Pageable pageable);

  /**
   * Find product by id
   * @param id Product ID
   * @return {@link Product}
   */
  Optional<Product> findById(BigInteger id);
}
