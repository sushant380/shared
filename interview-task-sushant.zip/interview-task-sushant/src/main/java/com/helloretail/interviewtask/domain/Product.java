package com.helloretail.interviewtask.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * Product domain entity. This can be attached to DB table. @Entity and @Id should be placed to make
 * it JPA entity.
 */
@Data
@NoArgsConstructor
public class Product {
  private BigInteger id;
  private String title;
  private BigDecimal price;
  private String image;
}
